using MediatR;
using Microsoft.Extensions.Logging;
using ProjectService.Application.Interfaces;
using ProjectService.Domain.Exceptions;
using System.Net.Http.Json;
using System.Text;
using System.Text.RegularExpressions;

namespace ProjectService.Application.Features.ExportProject;

/// <summary>
/// Handles project export with theme CSS injection and SEO meta tags
/// </summary>
public class ExportProjectHandler : IRequestHandler<ExportProjectCommand, ExportProjectResponse>
{
    private readonly IProjectRepository _projectRepo;
    private readonly ILogger<ExportProjectHandler> _logger;
    private readonly HttpClient _httpClient;

    private static readonly HashSet<string> ValidFormats = new()
    {
        "html", "react", "nextjs", "zip"
    };

    public ExportProjectHandler(
        IProjectRepository projectRepo,
        ILogger<ExportProjectHandler> logger,
        HttpClient httpClient)
    {
        _projectRepo = projectRepo;
        _logger = logger;
        _httpClient = httpClient;
    }

    public async Task<ExportProjectResponse> Handle(
        ExportProjectCommand req,
        CancellationToken ct)
    {
        try
        {
            // 1. Validate format
            if (!ValidFormats.Contains(req.Format.ToLower()))
            {
                throw new ArgumentException(
                    $"Invalid export format. Must be one of: {string.Join(", ", ValidFormats)}");
            }

            // 2. Get and validate project
            var project = await _projectRepo.GetByIdAsync(req.ProjectId)
                ?? throw new ProjectNotFoundException(req.ProjectId);

            if (project.UserId != req.UserId)
            {
                _logger.LogWarning("Unauthorized export attempt for project {ProjectId} by user {UserId}",
                    req.ProjectId, req.UserId);
                throw new InvalidOperationException("Permission denied");
            }

            // 3. Call export-service to generate code
            var exportResult = await CallExportService(req.ProjectId, req.Format, ct);

            // 4. If HTML format, inject theme CSS and SEO meta tags
            if (req.Format.ToLower() == "html")
            {
                var htmlWithTheme = await InjectThemeAndSeo(exportResult, project);
                return await SaveAndReturn(htmlWithTheme, req.ProjectId, req.Format);
            }

            // 5. For other formats, return export-service result
            _logger.LogInformation("Project {ProjectId} exported in {Format} format by user {UserId}",
                req.ProjectId, req.Format, req.UserId);

            return exportResult;
        }
        catch (ProjectNotFoundException ex)
        {
            _logger.LogError(ex, "Project not found during export: {ProjectId}", req.ProjectId);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error exporting project {ProjectId}", req.ProjectId);
            throw;
        }
    }

    /// <summary>
    /// Call export-service to generate code
    /// </summary>
    private async Task<ExportProjectResponse> CallExportService(
        Guid projectId,
        string format,
        CancellationToken ct)
    {
        try
        {
            // Export service URL (docker internal network)
            var exportServiceUrl = Environment.GetEnvironmentVariable("EXPORT_SERVICE_URL") 
                ?? "http://export-service:5004";

            var url = $"{exportServiceUrl}/api/export/{projectId}/{format}";

            var response = await _httpClient.PostAsync(url, null, ct);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(ct);
                throw new HttpRequestException(
                    $"Export service returned {response.StatusCode}: {error}");
            }

            // Read as blob for ZIP download
            var fileBytes = await response.Content.ReadAsByteArrayAsync(ct);
            var fileName = $"project-{projectId:N}-{format}.zip";
            var downloadUrl = $"/api/downloads/{projectId}/{fileName}";

            return new ExportProjectResponse(
                Success: true,
                DownloadUrl: downloadUrl,
                FileName: fileName,
                FileSize: fileBytes.Length,
                Message: $"Project exported successfully in {format} format"
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to call export-service for project {ProjectId}", projectId);
            throw;
        }
    }

    /// <summary>
    /// Inject theme CSS and SEO meta tags into HTML
    /// </summary>
    private async Task<string> InjectThemeAndSeo(ExportProjectResponse exportResult, Domain.Entities.Project project)
    {
        // Generate theme CSS
        var themeCss = GenerateThemeCss(project);

        // Generate SEO meta tags
        var seoMetaTags = GenerateSeoMetaTags(project);

        // In production, would read the actual HTML from export-service
        // For now, creating a complete template
        var html = CreateHtmlTemplate(project, themeCss, seoMetaTags);

        return html;
    }

    /// <summary>
    /// Generate CSS variables from theme settings
    /// </summary>
    private string GenerateThemeCss(Domain.Entities.Project project)
    {
        var primaryColor = project.PrimaryColor ?? "#6366F1";
        var secondaryColor = project.SecondaryColor ?? "#10B981";
        var accentColor = project.AccentColor ?? "#EF4444";
        var backgroundColor = project.BackgroundColor ?? "#FFFFFF";
        var textColor = project.TextColor ?? "#1F2937";
        var fontFamily = project.FontFamily ?? "Poppins";
        var fontSizeBase = project.FontSizeBase ?? "16";
        var borderRadius = project.BorderRadius ?? "8";

        return $@"
:root {{
  --color-primary: {primaryColor};
  --color-secondary: {secondaryColor};
  --color-accent: {accentColor};
  --color-bg: {backgroundColor};
  --color-text: {textColor};
  --font-family: '{fontFamily}', system-ui, -apple-system, sans-serif;
  --font-size-base: {fontSizeBase}px;
  --border-radius: {borderRadius}px;
}}

* {{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}}

body {{
  font-family: var(--font-family);
  font-size: var(--font-size-base);
  color: var(--color-text);
  background-color: var(--color-bg);
  line-height: 1.6;
}}

a {{
  color: var(--color-primary);
  text-decoration: none;
}}

a:hover {{
  text-decoration: underline;
}}

button, input[type=""submit""], input[type=""button""] {{
  background-color: var(--color-primary);
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: var(--border-radius);
  cursor: pointer;
  font-family: var(--font-family);
  font-size: var(--font-size-base);
  transition: background-color 0.3s ease;
}}

button:hover {{
  background-color: var(--color-secondary);
}}

input, textarea, select {{
  border: 1px solid #ddd;
  border-radius: var(--border-radius);
  padding: 8px 12px;
  font-family: var(--font-family);
  font-size: var(--font-size-base);
}}

h1, h2, h3, h4, h5, h6 {{
  color: var(--color-text);
  margin: 1em 0 0.5em 0;
}}

.accent {{
  color: var(--color-accent);
}}

.primary {{
  color: var(--color-primary);
}}

.secondary {{
  color: var(--color-secondary);
}}
";
    }

    /// <summary>
    /// Generate SEO meta tags from project data
    /// </summary>
    private string GenerateSeoMetaTags(Domain.Entities.Project project)
    {
        var seoTitle = project.SeoTitle ?? project.Name ?? "Untitled Project";
        var seoDescription = project.SeoDescription ?? "A website created with TechBirdsFly";
        var seoKeywords = project.SeoKeywords ?? "website,design,portfolio";
        var ogTitle = project.OgTitle ?? seoTitle;
        var ogDescription = project.OgDescription ?? seoDescription;
        var ogImage = project.OgImageUrl ?? "";
        var primaryColor = project.PrimaryColor ?? "#6366F1";

        var metaTags = new StringBuilder();
        metaTags.AppendLine("    <meta charset=\"UTF-8\" />");
        metaTags.AppendLine("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />");
        metaTags.AppendLine($"    <title>{EscapeHtml(seoTitle)}</title>");
        metaTags.AppendLine($"    <meta name=\"description\" content=\"{EscapeHtml(seoDescription)}\" />");
        metaTags.AppendLine($"    <meta name=\"keywords\" content=\"{EscapeHtml(seoKeywords)}\" />");
        metaTags.AppendLine($"    <meta name=\"theme-color\" content=\"{primaryColor}\" />");
        
        // Open Graph tags
        metaTags.AppendLine($"    <meta property=\"og:title\" content=\"{EscapeHtml(ogTitle)}\" />");
        metaTags.AppendLine($"    <meta property=\"og:description\" content=\"{EscapeHtml(ogDescription)}\" />");
        if (!string.IsNullOrWhiteSpace(ogImage))
        {
            metaTags.AppendLine($"    <meta property=\"og:image\" content=\"{EscapeHtml(ogImage)}\" />");
        }
        metaTags.AppendLine("    <meta property=\"og:type\" content=\"website\" />");

        return metaTags.ToString();
    }

    /// <summary>
    /// Create complete HTML document with theme and SEO
    /// </summary>
    private string CreateHtmlTemplate(
        Domain.Entities.Project project,
        string themeCss,
        string seoMetaTags)
    {
        var projectName = EscapeHtml(project.Name ?? "Untitled Project");
        var projectDescription = EscapeHtml(project.SeoDescription ?? "A website created with TechBirdsFly");
        var thumbnailUrl = project.ThumbnailUrl ?? "";

        return $@"<!DOCTYPE html>
<html lang=""en"">
<head>
{seoMetaTags}
    <style>
{themeCss}
    </style>
</head>
<body>
    <div class=""container"" style=""max-width: 1200px; margin: 0 auto; padding: 20px;"">
        <header style=""text-align: center; padding: 40px 0; border-bottom: 1px solid #eee;"">
            {(string.IsNullOrWhiteSpace(thumbnailUrl) ? "" : $@"<img src=""{thumbnailUrl}"" alt=""{projectName}"" style=""max-width: 200px; height: auto; margin-bottom: 20px;"">")}
            <h1>{projectName}</h1>
            <p style=""font-size: 1.1em; color: var(--color-text); opacity: 0.8; margin-top: 10px;"">{projectDescription}</p>
        </header>

        <main style=""padding: 40px 0;"">
            <section style=""background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-secondary) 100%); color: white; padding: 40px; border-radius: var(--border-radius); margin-bottom: 40px;"">
                <h2>Welcome to {projectName}</h2>
                <p style=""margin-top: 10px; font-size: 1.1em;"">{projectDescription}</p>
            </section>

            <section style=""display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;"">
                <div style=""border: 1px solid #eee; padding: 20px; border-radius: var(--border-radius);"">
                    <h3 style=""color: var(--color-primary);"">🎨 Customizable Design</h3>
                    <p>Your project features a fully customized theme with colors, fonts, and spacing tailored to your brand.</p>
                </div>
                <div style=""border: 1px solid #eee; padding: 20px; border-radius: var(--border-radius);"">
                    <h3 style=""color: var(--color-primary);"">📱 Responsive Layout</h3>
                    <p>This site adapts beautifully to all screen sizes, from mobile phones to large desktop displays.</p>
                </div>
                <div style=""border: 1px solid #eee; padding: 20px; border-radius: var(--border-radius);"">
                    <h3 style=""color: var(--color-primary);"">🚀 Ready to Deploy</h3>
                    <p>Your exported project is production-ready and can be deployed to any web hosting platform.</p>
                </div>
            </section>
        </main>

        <footer style=""border-top: 1px solid #eee; padding: 20px 0; margin-top: 40px; text-align: center; opacity: 0.6;"">
            <p>Created with TechBirdsFly • {DateTime.UtcNow:yyyy-MM-dd}</p>
        </footer>
    </div>
</body>
</html>";
    }

    /// <summary>
    /// Save HTML to file and return download info
    /// </summary>
    private Task<ExportProjectResponse> SaveAndReturn(
        string html,
        Guid projectId,
        string format)
    {
        // In production, would save to file storage and return download URL
        // For now, returning mock response
        var fileName = $"project-{projectId:N}.html";
        var fileSize = Encoding.UTF8.GetByteCount(html);

        return Task.FromResult(new ExportProjectResponse(
            Success: true,
            DownloadUrl: $"/api/downloads/{projectId}/{fileName}",
            FileName: fileName,
            FileSize: fileSize,
            Message: "Project exported successfully with theme CSS and SEO tags"
        ));
    }

    private static string EscapeHtml(string text)
    {
        if (string.IsNullOrEmpty(text))
            return text;

        return Regex.Replace(text, "[&<>\"']", m => m.Value switch
        {
            "&" => "&amp;",
            "<" => "&lt;",
            ">" => "&gt;",
            "\"" => "&quot;",
            "'" => "&#39;",
            _ => m.Value
        });
    }
}
