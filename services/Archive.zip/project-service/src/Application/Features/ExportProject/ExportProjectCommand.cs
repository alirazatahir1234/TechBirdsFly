using MediatR;

namespace ProjectService.Application.Features.ExportProject;

/// <summary>
/// Export a project in the specified format with theme CSS and SEO meta tags
/// </summary>
public record ExportProjectCommand(
    Guid ProjectId,
    Guid UserId,
    string Format  // "html", "react", "nextjs", "zip"
) : IRequest<ExportProjectResponse>;

/// <summary>
/// Response from export operation containing download URL and file info
/// </summary>
public record ExportProjectResponse(
    bool Success,
    string DownloadUrl,
    string FileName,
    long FileSize,
    string Message
);
