namespace TechBirdsFly.ProjectService.Domain.Entities;

public class ProjectVersion
{
    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public int VersionNumber { get; private set; }
    public string Html { get; private set; }
    public DateTime CreatedAt { get; private set; }

    public ProjectVersion(Guid projectId, int versionNumber, string html)
    {
        Id = Guid.NewGuid();
        ProjectId = projectId;
        VersionNumber = versionNumber;
        Html = html;
        CreatedAt = DateTime.UtcNow;
    }
}
