using TechBirdsFly.ProjectService.Domain.Common;

namespace TechBirdsFly.ProjectService.Domain.Entities;

public class Project : BaseEntity
{
    public Guid UserId { get; private set; }
    public string Name { get; private set; }
    public string Industry { get; private set; }
    public string Style { get; private set; }
    public string Palette { get; private set; }
    public string? ThumbnailUrl { get; private set; }
    
    // SEO Fields
    public string? SeoTitle { get; private set; }
    public string? SeoDescription { get; private set; }
    public string? SeoKeywords { get; private set; }
    public string? OgTitle { get; private set; }
    public string? OgDescription { get; private set; }
    public string? OgImageUrl { get; private set; }
    
    // Theme Fields (Colors & Fonts)
    public string? PrimaryColor { get; private set; }
    public string? SecondaryColor { get; private set; }
    public string? AccentColor { get; private set; }
    public string? BackgroundColor { get; private set; }
    public string? TextColor { get; private set; }
    public string? FontFamily { get; private set; }
    public string? FontSizeBase { get; private set; }
    public string? BorderRadius { get; private set; }
    
    public bool IsDeleted { get; private set; } = false;
    public DateTime? DeletedAt { get; private set; }

    public List<ProjectVersion> Versions { get; private set; } = new();

    public Project(Guid userId, string name, string industry, string style, string palette)
    {
        UserId = userId;
        Name = name;
        Industry = industry;
        Style = style;
        Palette = palette;
    }

    public void Rename(string name)
    {
        Name = name;
        UpdatedAt = DateTime.UtcNow;
    }

    public void UpdateMetadata(string industry, string style, string palette)
    {
        Industry = industry;
        Style = style;
        Palette = palette;
        UpdatedAt = DateTime.UtcNow;
    }

    public void MoveToTrash()
    {
        IsDeleted = true;
        DeletedAt = DateTime.UtcNow;
        UpdatedAt = DateTime.UtcNow;
    }

    public void RestoreFromTrash()
    {
        IsDeleted = false;
        DeletedAt = null;
        UpdatedAt = DateTime.UtcNow;
    }

    public void UpdateThumbnail(string? url)
    {
        ThumbnailUrl = url;
        UpdatedAt = DateTime.UtcNow;
    }

    public void UpdateSeo(
        string? seoTitle,
        string? seoDescription,
        string? seoKeywords,
        string? ogTitle,
        string? ogDescription,
        string? ogImageUrl)
    {
        SeoTitle = seoTitle;
        SeoDescription = seoDescription;
        SeoKeywords = seoKeywords;
        OgTitle = ogTitle;
        OgDescription = ogDescription;
        OgImageUrl = ogImageUrl;
        UpdatedAt = DateTime.UtcNow;
    }

    public void UpdateTheme(
        string? primaryColor,
        string? secondaryColor,
        string? accentColor,
        string? backgroundColor,
        string? textColor,
        string? fontFamily,
        string? fontSizeBase,
        string? borderRadius)
    {
        PrimaryColor = primaryColor;
        SecondaryColor = secondaryColor;
        AccentColor = accentColor;
        BackgroundColor = backgroundColor;
        TextColor = textColor;
        FontFamily = fontFamily;
        FontSizeBase = fontSizeBase;
        BorderRadius = borderRadius;
        UpdatedAt = DateTime.UtcNow;
    }
}
