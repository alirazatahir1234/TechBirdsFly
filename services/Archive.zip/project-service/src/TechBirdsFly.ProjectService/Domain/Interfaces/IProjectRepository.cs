using TechBirdsFly.ProjectService.Domain.Entities;

namespace TechBirdsFly.ProjectService.Domain.Interfaces;

public interface IProjectRepository
{
    Task<Project?> GetByIdAsync(Guid id);
    Task<List<Project>> GetByUserIdAsync(Guid userId);
    Task<List<Project>> GetAllAsync();
    Task AddAsync(Project project);
    Task UpdateAsync(Project project);
    Task DeleteAsync(Project project);
    Task SaveChangesAsync();
}
