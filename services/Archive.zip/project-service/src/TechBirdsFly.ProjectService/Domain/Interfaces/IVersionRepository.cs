using TechBirdsFly.ProjectService.Domain.Entities;

namespace TechBirdsFly.ProjectService.Domain.Interfaces;

public interface IVersionRepository
{
    Task<int> GetLastVersionAsync(Guid projectId);
    Task AddAsync(ProjectVersion version);
    Task<List<ProjectVersion>> GetByProjectIdAsync(Guid projectId);
    Task SaveChangesAsync();
}
