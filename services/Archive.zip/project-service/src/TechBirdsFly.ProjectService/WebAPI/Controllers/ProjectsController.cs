using MediatR;
using Microsoft.AspNetCore.Mvc;
using TechBirdsFly.ProjectService.Application.DTOs;
using TechBirdsFly.ProjectService.Application.Features.CreateProject;
using TechBirdsFly.ProjectService.Application.Features.DeleteProject;
using TechBirdsFly.ProjectService.Application.Features.DuplicateProject;
using TechBirdsFly.ProjectService.Application.Features.GetProject;
using TechBirdsFly.ProjectService.Application.Features.ListProjects;
using TechBirdsFly.ProjectService.Application.Features.SaveVersion;
using TechBirdsFly.ProjectService.Application.Features.MoveToTrash;
using TechBirdsFly.ProjectService.Application.Features.RestoreProject;
using TechBirdsFly.ProjectService.Application.Features.PermanentDelete;
using TechBirdsFly.ProjectService.Application.Features.ListTrash;
using TechBirdsFly.ProjectService.Application.Features.UpdateSeo;
using TechBirdsFly.ProjectService.Application.Features.UpdateTheme;
using TechBirdsFly.ProjectService.Application.Features.ExportProject;

namespace TechBirdsFly.ProjectService.WebAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProjectsController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<ProjectsController> _logger;

    public ProjectsController(IMediator mediator, ILogger<ProjectsController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    /// <summary>
    /// Create new project with initial HTML
    /// </summary>
    [HttpPost("create")]
    public async Task<IActionResult> CreateProject(
        [FromBody] CreateProjectRequest request,
        CancellationToken ct)
    {
        try
        {
            var command = new CreateProjectCommand(
                request.UserId,
                request.Name,
                request.Industry,
                request.Style,
                request.Palette,
                request.Html
            );

            var projectId = await _mediator.Send(command, ct);
            return CreatedAtAction(nameof(GetProject), new { projectId },
                new ApiResponse<Guid> { Success = true, Data = projectId, Message = "Project created successfully" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating project");
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Get project by ID with latest version
    /// </summary>
    [HttpGet("{projectId}")]
    public async Task<IActionResult> GetProject(Guid projectId, CancellationToken ct)
    {
        try
        {
            var query = new GetProjectQuery(projectId);
            var project = await _mediator.Send(query, ct);
            return Ok(new ApiResponse<ProjectDto> { Success = true, Data = project });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting project {ProjectId}", projectId);
            return NotFound(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// List all projects for user
    /// </summary>
    [HttpGet("user/{userId}")]
    public async Task<IActionResult> ListProjects(Guid userId, CancellationToken ct)
    {
        try
        {
            var query = new ListProjectsQuery(userId);
            var projects = await _mediator.Send(query, ct);
            return Ok(new ApiResponse<List<ProjectListDto>> 
            { 
                Success = true, 
                Data = projects, 
                Message = $"Retrieved {projects.Count} projects"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing projects for user {UserId}", userId);
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Save new version of project
    /// </summary>
    [HttpPost("{projectId}/versions")]
    public async Task<IActionResult> SaveVersion(
        Guid projectId,
        [FromBody] SaveVersionRequest request,
        CancellationToken ct)
    {
        try
        {
            var command = new SaveVersionCommand(projectId, request.Html);
            var versionNumber = await _mediator.Send(command, ct);
            return CreatedAtAction(nameof(GetProject), new { projectId },
                new ApiResponse<int> 
                { 
                    Success = true, 
                    Data = versionNumber, 
                    Message = $"Version {versionNumber} saved" 
                });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error saving version for project {ProjectId}", projectId);
            return NotFound(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Delete project
    /// </summary>
    [HttpDelete("{projectId}")]
    public async Task<IActionResult> DeleteProject(Guid projectId, CancellationToken ct)
    {
        try
        {
            var command = new DeleteProjectCommand(projectId);
            var result = await _mediator.Send(command, ct);
            return Ok(new ApiResponse<bool> 
            { 
                Success = result, 
                Data = result, 
                Message = "Project deleted successfully" 
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting project {ProjectId}", projectId);
            return NotFound(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Duplicate existing project
    /// </summary>
    [HttpPost("{projectId}/duplicate")]
    public async Task<IActionResult> DuplicateProject(
        Guid projectId,
        [FromBody] DuplicateProjectRequest request,
        CancellationToken ct)
    {
        try
        {
            var command = new DuplicateProjectCommand(projectId, request.UserId);
            var newProjectId = await _mediator.Send(command, ct);
            return CreatedAtAction(nameof(GetProject), new { projectId = newProjectId },
                new ApiResponse<Guid> 
                { 
                    Success = true, 
                    Data = newProjectId, 
                    Message = "Project duplicated successfully" 
                });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error duplicating project {ProjectId}", projectId);
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Move project to trash (soft delete)
    /// </summary>
    [HttpPut("trash/{projectId}")]
    public async Task<IActionResult> MoveToTrash(
        Guid projectId,
        [FromBody] MoveToTrashRequest request,
        CancellationToken ct)
    {
        try
        {
            var command = new MoveToTrashCommand(projectId, request.UserId);
            var result = await _mediator.Send(command, ct);
            return Ok(new ApiResponse<bool>
            {
                Success = result,
                Data = result,
                Message = "Project moved to trash successfully"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error moving project {ProjectId} to trash", projectId);
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Restore project from trash
    /// </summary>
    [HttpPut("restore/{projectId}")]
    public async Task<IActionResult> RestoreProject(
        Guid projectId,
        [FromBody] RestoreProjectRequest request,
        CancellationToken ct)
    {
        try
        {
            var command = new RestoreProjectCommand(projectId, request.UserId);
            var result = await _mediator.Send(command, ct);
            return Ok(new ApiResponse<bool>
            {
                Success = result,
                Data = result,
                Message = "Project restored from trash successfully"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error restoring project {ProjectId} from trash", projectId);
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Permanently delete project from database (hard delete)
    /// </summary>
    [HttpDelete("permanent/{projectId}")]
    public async Task<IActionResult> PermanentDelete(
        Guid projectId,
        [FromBody] PermanentDeleteRequest request,
        CancellationToken ct)
    {
        try
        {
            var command = new PermanentDeleteCommand(projectId, request.UserId);
            var result = await _mediator.Send(command, ct);
            return Ok(new ApiResponse<bool>
            {
                Success = result,
                Data = result,
                Message = "Project permanently deleted"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error permanently deleting project {ProjectId}", projectId);
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// List all trashed projects for user
    /// </summary>
    [HttpGet("trash/user/{userId}")]
    public async Task<IActionResult> ListTrash(Guid userId, CancellationToken ct)
    {
        try
        {
            var query = new ListTrashQuery(userId);
            var trashedProjects = await _mediator.Send(query, ct);
            return Ok(new ApiResponse<List<ProjectDto>>
            {
                Success = true,
                Data = trashedProjects,
                Message = $"Retrieved {trashedProjects.Count} trashed projects"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing trash for user {UserId}", userId);
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Update project SEO and OG meta tags
    /// </summary>
    [HttpPut("{projectId}/seo")]
    public async Task<IActionResult> UpdateSeo(
        Guid projectId,
        [FromBody] UpdateSeoRequest request,
        CancellationToken ct)
    {
        try
        {
            var command = new UpdateSeoCommand(
                projectId,
                request.UserId,
                request.SeoTitle,
                request.SeoDescription,
                request.SeoKeywords,
                request.OgTitle,
                request.OgDescription,
                request.OgImageUrl
            );

            var result = await _mediator.Send(command, ct);
            return Ok(new ApiResponse<bool>
            {
                Success = result,
                Data = result,
                Message = "SEO settings updated successfully"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating SEO for project {ProjectId}", projectId);
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Update project theme (colors & fonts)
    /// </summary>
    [HttpPut("{projectId}/theme")]
    public async Task<IActionResult> UpdateTheme(
        Guid projectId,
        [FromBody] UpdateThemeRequest request,
        CancellationToken ct)
    {
        try
        {
            var command = new UpdateThemeCommand(
                projectId,
                request.UserId,
                request.PrimaryColor,
                request.SecondaryColor,
                request.AccentColor,
                request.BackgroundColor,
                request.TextColor,
                request.FontFamily,
                request.FontSizeBase,
                request.BorderRadius
            );

            var result = await _mediator.Send(command, ct);
            return Ok(new ApiResponse<bool>
            {
                Success = result,
                Data = result,
                Message = "Theme settings updated successfully"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating theme for project {ProjectId}", projectId);
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Export project in specified format with theme CSS and SEO meta tags
    /// </summary>
    [HttpPost("{projectId}/export")]
    public async Task<IActionResult> ExportProject(
        Guid projectId,
        [FromBody] ExportProjectRequest request,
        CancellationToken ct)
    {
        try
        {
            var command = new ExportProjectCommand(
                projectId,
                request.UserId,
                request.Format
            );

            var result = await _mediator.Send(command, ct);
            return Ok(new ApiResponse<ExportProjectResponse>
            {
                Success = result.Success,
                Data = result,
                Message = result.Message
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error exporting project {ProjectId}", projectId);
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Health check
    /// </summary>
    [HttpGet("health/status")]
    public IActionResult Health()
    {
        return Ok(new { status = "healthy", timestamp = DateTime.UtcNow });
    }
}

public record CreateProjectRequest(string Name, string Industry, string Style, string Palette, string Html, Guid UserId);
public record SaveVersionRequest(string Html);
public record DuplicateProjectRequest(Guid UserId);
public record MoveToTrashRequest(Guid UserId);
public record RestoreProjectRequest(Guid UserId);
public record PermanentDeleteRequest(Guid UserId);
public record UpdateSeoRequest(Guid UserId, string? SeoTitle, string? SeoDescription, string? SeoKeywords, string? OgTitle, string? OgDescription, string? OgImageUrl);
public record UpdateThemeRequest(Guid UserId, string? PrimaryColor, string? SecondaryColor, string? AccentColor, string? BackgroundColor, string? TextColor, string? FontFamily, string? FontSizeBase, string? BorderRadius);
public record ExportProjectRequest(Guid UserId, string Format);

public class ApiResponse<T>
{
    public bool Success { get; set; }
    public T? Data { get; set; }
    public string? Message { get; set; }
}
