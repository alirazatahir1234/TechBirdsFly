using MediatR;
using TechBirdsFly.ProjectService.Application.DTOs;

namespace TechBirdsFly.ProjectService.Application.Features.ListTrash;

/// <summary>
/// Query to list all trashed projects for a user
/// </summary>
public record ListTrashQuery(Guid UserId) : IRequest<List<ProjectDto>>;
