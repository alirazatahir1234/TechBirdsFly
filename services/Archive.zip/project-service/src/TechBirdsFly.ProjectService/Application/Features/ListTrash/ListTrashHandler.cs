using MediatR;
using Serilog;
using TechBirdsFly.ProjectService.Application.DTOs;
using TechBirdsFly.ProjectService.Domain.Interfaces;

namespace TechBirdsFly.ProjectService.Application.Features.ListTrash;

/// <summary>
/// Handler to list all deleted projects for a user
/// </summary>
public class ListTrashHandler : IRequestHandler<ListTrashQuery, List<ProjectDto>>
{
    private readonly IProjectRepository _projects;

    public ListTrashHandler(IProjectRepository projects)
    {
        _projects = projects;
    }

    public async Task<List<ProjectDto>> Handle(ListTrashQuery req, CancellationToken ct)
    {
        Log.Information("Listing trash for user {UserId}", req.UserId);

        // Get all deleted projects for user
        var deletedProjects = await _projects.GetAllAsync();
        var userTrash = deletedProjects
            .Where(p => p.UserId == req.UserId && p.IsDeleted)
            .OrderByDescending(p => p.DeletedAt)
            .ToList();

        Log.Information("Found {Count} projects in trash for user {UserId}", userTrash.Count, req.UserId);

        return userTrash.Select(p => new ProjectDto(
            p.Id,
            p.Name,
            p.Industry,
            p.Style,
            p.Palette,
            p.Versions.OrderByDescending(v => v.VersionNumber).FirstOrDefault()?.Html ?? "",
            p.Versions.Count > 0 ? p.Versions.Max(v => v.VersionNumber) : 1
        )).ToList();
    }
}
