using MediatR;

namespace TechBirdsFly.ProjectService.Application.Features.DeleteProject;

public record DeleteProjectCommand(Guid ProjectId) : IRequest<bool>;
