using MediatR;
using TechBirdsFly.ProjectService.Domain.Exceptions;
using TechBirdsFly.ProjectService.Domain.Interfaces;

namespace TechBirdsFly.ProjectService.Application.Features.DeleteProject;

public class DeleteProjectHandler : IRequestHandler<DeleteProjectCommand, bool>
{
    private readonly IProjectRepository _repo;

    public DeleteProjectHandler(IProjectRepository repo)
    {
        _repo = repo;
    }

    public async Task<bool> Handle(DeleteProjectCommand req, CancellationToken ct)
    {
        var project = await _repo.GetByIdAsync(req.ProjectId)
            ?? throw new ProjectNotFoundException(req.ProjectId);

        await _repo.DeleteAsync(project);
        await _repo.SaveChangesAsync();

        return true;
    }
}
