using MediatR;
using TechBirdsFly.ProjectService.Domain.Entities;
using TechBirdsFly.ProjectService.Domain.Interfaces;
using TechBirdsFly.ProjectService.Domain.Exceptions;
using TechBirdsFly.ProjectService.Application.Features.GenerateThumbnail;

namespace TechBirdsFly.ProjectService.Application.Features.SaveVersion;

public class SaveVersionHandler : IRequestHandler<SaveVersionCommand, int>
{
    private readonly IProjectRepository _projects;
    private readonly IVersionRepository _versions;
    private readonly IMediator _mediator;
    private readonly ILogger<SaveVersionHandler> _logger;

    public SaveVersionHandler(
        IProjectRepository projects,
        IVersionRepository versions,
        IMediator mediator,
        ILogger<SaveVersionHandler> logger)
    {
        _projects = projects;
        _versions = versions;
        _mediator = mediator;
        _logger = logger;
    }

    public async Task<int> Handle(SaveVersionCommand req, CancellationToken ct)
    {
        var existing = await _projects.GetByIdAsync(req.ProjectId)
            ?? throw new ProjectNotFoundException(req.ProjectId);

        var lastVersion = await _versions.GetLastVersionAsync(req.ProjectId);
        var newVersion = lastVersion + 1;

        var version = new ProjectVersion(req.ProjectId, newVersion, req.Html);
        await _versions.AddAsync(version);
        await _versions.SaveChangesAsync();

        // Regenerate thumbnail for latest version (fire and forget)
        _ = Task.Run(async () =>
        {
            try
            {
                await _mediator.Send(new GenerateThumbnailCommand(req.ProjectId, req.Html), ct);
                _logger.LogInformation("Thumbnail updated for project {ProjectId} version {Version}", 
                    req.ProjectId, newVersion);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update thumbnail for project {ProjectId}", req.ProjectId);
            }
        }, ct);

        return newVersion;
    }
}
