using MediatR;

namespace TechBirdsFly.ProjectService.Application.Features.SaveVersion;

public record SaveVersionCommand(Guid ProjectId, string Html) : IRequest<int>;
