using MediatR;

namespace TechBirdsFly.ProjectService.Application.Features.UpdateSeo;

public record UpdateSeoCommand(
    Guid ProjectId,
    Guid UserId,
    string? SeoTitle,
    string? SeoDescription,
    string? SeoKeywords,
    string? OgTitle,
    string? OgDescription,
    string? OgImageUrl
) : IRequest<bool>;
