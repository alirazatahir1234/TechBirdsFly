using MediatR;
using TechBirdsFly.ProjectService.Domain.Interfaces;
using TechBirdsFly.ProjectService.Domain.Exceptions;

namespace TechBirdsFly.ProjectService.Application.Features.UpdateSeo;

public class UpdateSeoHandler : IRequestHandler<UpdateSeoCommand, bool>
{
    private readonly IProjectRepository _repo;
    private readonly ILogger<UpdateSeoHandler> _logger;

    public UpdateSeoHandler(IProjectRepository repo, ILogger<UpdateSeoHandler> logger)
    {
        _repo = repo;
        _logger = logger;
    }

    public async Task<bool> Handle(UpdateSeoCommand req, CancellationToken ct)
    {
        try
        {
            var project = await _repo.GetByIdAsync(req.ProjectId)
                ?? throw new ProjectNotFoundException(req.ProjectId);

            // Verify user ownership
            if (project.UserId != req.UserId)
            {
                _logger.LogWarning("User {UserId} attempted to update SEO for project {ProjectId} they don't own",
                    req.UserId, req.ProjectId);
                throw new InvalidOperationException("You don't have permission to update this project's SEO settings");
            }

            project.UpdateSeo(
                req.SeoTitle,
                req.SeoDescription,
                req.SeoKeywords,
                req.OgTitle,
                req.OgDescription,
                req.OgImageUrl
            );

            await _repo.SaveChangesAsync();

            _logger.LogInformation("SEO settings updated for project {ProjectId}", req.ProjectId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating SEO settings for project {ProjectId}", req.ProjectId);
            throw;
        }
    }
}
