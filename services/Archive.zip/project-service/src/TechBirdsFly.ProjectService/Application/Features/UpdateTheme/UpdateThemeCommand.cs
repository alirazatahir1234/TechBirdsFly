using MediatR;

namespace TechBirdsFly.ProjectService.Application.Features.UpdateTheme;

public record UpdateThemeCommand(
    Guid ProjectId,
    Guid UserId,
    string? PrimaryColor,
    string? SecondaryColor,
    string? AccentColor,
    string? BackgroundColor,
    string? TextColor,
    string? FontFamily,
    string? FontSizeBase,
    string? BorderRadius
) : IRequest<bool>;
