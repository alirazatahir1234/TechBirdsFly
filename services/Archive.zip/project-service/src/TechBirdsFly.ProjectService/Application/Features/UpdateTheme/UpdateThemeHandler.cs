using MediatR;
using System.Text.RegularExpressions;
using TechBirdsFly.ProjectService.Domain.Interfaces;
using TechBirdsFly.ProjectService.Domain.Exceptions;

namespace TechBirdsFly.ProjectService.Application.Features.UpdateTheme;

public class UpdateThemeHandler : IRequestHandler<UpdateThemeCommand, bool>
{
    private readonly IProjectRepository _repo;
    private readonly ILogger<UpdateThemeHandler> _logger;
    private static readonly HashSet<string> AllowedFontFamilies = new()
    {
        "Poppins", "Inter", "Georgia", "Arial", "Courier", "Times New Roman", "Verdana"
    };

    public UpdateThemeHandler(IProjectRepository repo, ILogger<UpdateThemeHandler> logger)
    {
        _repo = repo;
        _logger = logger;
    }

    public async Task<bool> Handle(UpdateThemeCommand req, CancellationToken ct)
    {
        try
        {
            var project = await _repo.GetByIdAsync(req.ProjectId)
                ?? throw new ProjectNotFoundException(req.ProjectId);

            // Verify user ownership
            if (project.UserId != req.UserId)
            {
                _logger.LogWarning("User {UserId} attempted to update theme for project they don't own",
                    req.UserId);
                throw new InvalidOperationException("You don't have permission to update this project's theme settings");
            }

            // Validate colors (HEX format: #RRGGBB)
            if (!ValidateColor(req.PrimaryColor) || !ValidateColor(req.SecondaryColor) ||
                !ValidateColor(req.AccentColor) || !ValidateColor(req.BackgroundColor) ||
                !ValidateColor(req.TextColor))
            {
                throw new ArgumentException("Invalid color format. Please use HEX format (#RRGGBB)");
            }

            // Validate font family
            if (!string.IsNullOrWhiteSpace(req.FontFamily) && !AllowedFontFamilies.Contains(req.FontFamily))
            {
                throw new ArgumentException($"Invalid font family. Allowed: {string.Join(", ", AllowedFontFamilies)}");
            }

            // Validate font size (14-24)
            if (!ValidateNumberRange(req.FontSizeBase, 14, 24))
            {
                throw new ArgumentException("Font size must be between 14 and 24 px");
            }

            // Validate border radius (0-24)
            if (!ValidateNumberRange(req.BorderRadius, 0, 24))
            {
                throw new ArgumentException("Border radius must be between 0 and 24 px");
            }

            project.UpdateTheme(
                req.PrimaryColor,
                req.SecondaryColor,
                req.AccentColor,
                req.BackgroundColor,
                req.TextColor,
                req.FontFamily,
                req.FontSizeBase,
                req.BorderRadius
            );

            await _repo.SaveChangesAsync();

            _logger.LogInformation("Theme settings updated for project {ProjectId}", req.ProjectId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating theme settings for project {ProjectId}", req.ProjectId);
            throw;
        }
    }

    private static bool ValidateColor(string? color)
    {
        if (string.IsNullOrWhiteSpace(color))
            return true; // Nullable, so null/empty is valid

        return Regex.IsMatch(color, @"^#[0-9A-Fa-f]{6}$");
    }

    private static bool ValidateNumberRange(string? value, int min, int max)
    {
        if (string.IsNullOrWhiteSpace(value))
            return true; // Nullable, so null/empty is valid

        if (int.TryParse(value, out var number))
            return number >= min && number <= max;

        return false;
    }
}
