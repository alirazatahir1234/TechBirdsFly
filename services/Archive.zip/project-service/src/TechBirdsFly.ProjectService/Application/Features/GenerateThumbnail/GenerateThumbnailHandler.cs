using MediatR;
using System.Text;
using System.Text.Json;
using TechBirdsFly.ProjectService.Domain.Interfaces;
using TechBirdsFly.ProjectService.Domain.Exceptions;

namespace TechBirdsFly.ProjectService.Application.Features.GenerateThumbnail;

public class GenerateThumbnailHandler : IRequestHandler<GenerateThumbnailCommand, bool>
{
    private readonly IProjectRepository _projects;
    private readonly IHttpClientFactory _http;
    private readonly ILogger<GenerateThumbnailHandler> _logger;

    public GenerateThumbnailHandler(
        IProjectRepository projects,
        IHttpClientFactory http,
        ILogger<GenerateThumbnailHandler> logger)
    {
        _projects = projects;
        _http = http;
        _logger = logger;
    }

    public async Task<bool> Handle(GenerateThumbnailCommand req, CancellationToken ct)
    {
        try
        {
            var project = await _projects.GetByIdAsync(req.ProjectId)
                ?? throw new ProjectNotFoundException(req.ProjectId);

            _logger.LogInformation("Generating thumbnail for project {ProjectId}", req.ProjectId);

            // Call media-service screenshot API
            var client = _http.CreateClient();
            var screenshotRequest = new { html = req.Html };
            var content = new StringContent(
                JsonSerializer.Serialize(screenshotRequest),
                Encoding.UTF8,
                "application/json"
            );

            var response = await client.PostAsync(
                "http://localhost:6002/api/media/screenshot",
                content,
                ct
            );

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError("Failed to capture screenshot: {StatusCode}", response.StatusCode);
                return false;
            }

            var responseContent = await response.Content.ReadAsStringAsync(ct);
            using var doc = JsonDocument.Parse(responseContent);
            var root = doc.RootElement;

            if (!root.TryGetProperty("base64", out var base64Element))
            {
                _logger.LogError("Screenshot response missing base64 data");
                return false;
            }

            var base64String = base64Element.GetString();
            if (string.IsNullOrEmpty(base64String))
            {
                _logger.LogError("Base64 string is empty");
                return false;
            }

            // Save base64 as data URI (simple approach - can be optimized to save to blob storage)
            var dataUri = $"data:image/png;base64,{base64String}";
            project.UpdateThumbnail(dataUri);
            await _projects.SaveChangesAsync();

            _logger.LogInformation("Thumbnail generated successfully for project {ProjectId}", req.ProjectId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating thumbnail for project {ProjectId}", req.ProjectId);
            return false;
        }
    }
}
