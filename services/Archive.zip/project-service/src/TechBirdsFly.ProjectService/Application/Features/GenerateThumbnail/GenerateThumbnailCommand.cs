using MediatR;

namespace TechBirdsFly.ProjectService.Application.Features.GenerateThumbnail;

public record GenerateThumbnailCommand(Guid ProjectId, string Html) : IRequest<bool>;
