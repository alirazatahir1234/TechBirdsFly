using MediatR;
using TechBirdsFly.ProjectService.Application.DTOs;

namespace TechBirdsFly.ProjectService.Application.Features.ListProjects;

public record ListProjectsQuery(Guid UserId) : IRequest<List<ProjectListDto>>;
