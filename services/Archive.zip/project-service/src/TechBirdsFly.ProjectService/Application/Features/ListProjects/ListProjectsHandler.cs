using MediatR;
using TechBirdsFly.ProjectService.Application.DTOs;
using TechBirdsFly.ProjectService.Domain.Interfaces;

namespace TechBirdsFly.ProjectService.Application.Features.ListProjects;

public class ListProjectsHandler : IRequestHandler<ListProjectsQuery, List<ProjectListDto>>
{
    private readonly IProjectRepository _repo;

    public ListProjectsHandler(IProjectRepository repo)
    {
        _repo = repo;
    }

    public async Task<List<ProjectListDto>> Handle(ListProjectsQuery req, CancellationToken ct)
    {
        var projects = await _repo.GetByUserIdAsync(req.UserId);

        return projects
            .OrderByDescending(p => p.CreatedAt)
            .Select(p => new ProjectListDto(
                p.Id,
                p.Name,
                p.Industry,
                p.Style,
                p.Palette,
                p.CreatedAt,
                p.ThumbnailUrl
            ))
            .ToList();
    }
}
