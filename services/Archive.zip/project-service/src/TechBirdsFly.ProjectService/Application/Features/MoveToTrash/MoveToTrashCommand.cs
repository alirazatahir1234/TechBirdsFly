using MediatR;

namespace TechBirdsFly.ProjectService.Application.Features.MoveToTrash;

/// <summary>
/// Command to move a project to trash (soft delete)
/// </summary>
public record MoveToTrashCommand(Guid ProjectId, Guid UserId) : IRequest<bool>;
