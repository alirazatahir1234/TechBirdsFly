using MediatR;
using Serilog;
using TechBirdsFly.ProjectService.Domain.Exceptions;
using TechBirdsFly.ProjectService.Domain.Interfaces;

namespace TechBirdsFly.ProjectService.Application.Features.MoveToTrash;

/// <summary>
/// Handler to move a project to trash
/// Performs soft delete by setting IsDeleted = true
/// </summary>
public class MoveToTrashHandler : IRequestHandler<MoveToTrashCommand, bool>
{
    private readonly IProjectRepository _projects;

    public MoveToTrashHandler(IProjectRepository projects)
    {
        _projects = projects;
    }

    public async Task<bool> Handle(MoveToTrashCommand req, CancellationToken ct)
    {
        Log.Information("Moving project {ProjectId} to trash", req.ProjectId);

        // Fetch project
        var project = await _projects.GetByIdAsync(req.ProjectId)
            ?? throw new ProjectNotFoundException(req.ProjectId);

        // Verify user owns this project
        if (project.UserId != req.UserId)
        {
            Log.Warning("User {UserId} attempted to trash project {ProjectId} they don't own", req.UserId, req.ProjectId);
            throw new InvalidOperationException("You do not have permission to move this project");
        }

        // Move to trash
        project.MoveToTrash();

        // Save changes
        await _projects.UpdateAsync(project);
        await _projects.SaveChangesAsync();

        Log.Information("Project {ProjectId} moved to trash successfully", req.ProjectId);
        return true;
    }
}
