using MediatR;
using TechBirdsFly.ProjectService.Application.DTOs;
using TechBirdsFly.ProjectService.Domain.Interfaces;
using TechBirdsFly.ProjectService.Domain.Exceptions;

namespace TechBirdsFly.ProjectService.Application.Features.GetProject;

public class GetProjectHandler : IRequestHandler<GetProjectQuery, ProjectDto>
{
    private readonly IProjectRepository _projects;
    private readonly IVersionRepository _versions;

    public GetProjectHandler(IProjectRepository projects, IVersionRepository versions)
    {
        _projects = projects;
        _versions = versions;
    }

    public async Task<ProjectDto> Handle(GetProjectQuery req, CancellationToken ct)
    {
        var project = await _projects.GetByIdAsync(req.ProjectId)
            ?? throw new ProjectNotFoundException(req.ProjectId);

        var versions = await _versions.GetByProjectIdAsync(req.ProjectId);
        if (versions.Count == 0)
            throw new Exception("No versions found for this project");

        var latest = versions.OrderByDescending(x => x.VersionNumber).First();

        return new ProjectDto(
            project.Id,
            project.Name,
            project.Industry,
            project.Style,
            project.Palette,
            latest.Html,
            latest.VersionNumber
        );
    }
}
