using MediatR;
using TechBirdsFly.ProjectService.Application.DTOs;

namespace TechBirdsFly.ProjectService.Application.Features.GetProject;

public record GetProjectQuery(Guid ProjectId) : IRequest<ProjectDto>;
