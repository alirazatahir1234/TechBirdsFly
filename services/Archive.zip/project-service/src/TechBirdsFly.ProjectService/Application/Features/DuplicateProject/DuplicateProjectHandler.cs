using MediatR;
using TechBirdsFly.ProjectService.Domain.Entities;
using TechBirdsFly.ProjectService.Domain.Interfaces;
using TechBirdsFly.ProjectService.Domain.Exceptions;

namespace TechBirdsFly.ProjectService.Application.Features.DuplicateProject;

public class DuplicateProjectHandler : IRequestHandler<DuplicateProjectCommand, Guid>
{
    private readonly IProjectRepository _projects;
    private readonly IVersionRepository _versions;

    public DuplicateProjectHandler(IProjectRepository projects, IVersionRepository versions)
    {
        _projects = projects;
        _versions = versions;
    }

    public async Task<Guid> Handle(DuplicateProjectCommand req, CancellationToken ct)
    {
        // 1. Fetch original project
        var project = await _projects.GetByIdAsync(req.ProjectId)
            ?? throw new ProjectNotFoundException(req.ProjectId);

        // 2. Load latest version
        var versions = await _versions.GetByProjectIdAsync(req.ProjectId);
        if (versions.Count == 0)
            throw new InvalidOperationException("Project has no versions");

        var latest = versions.OrderByDescending(v => v.VersionNumber).First();

        // 3. Create duplicated project
        var copyName = $"{project.Name} (Copy)";

        var duplicated = new Project(
            req.UserId,
            copyName,
            project.Industry,
            project.Style,
            project.Palette
        );

        await _projects.AddAsync(duplicated);
        await _projects.SaveChangesAsync();

        // 4. Create version 1 with copied HTML
        var newVersion = new ProjectVersion(duplicated.Id, 1, latest.Html);
        await _versions.AddAsync(newVersion);
        await _versions.SaveChangesAsync();

        return duplicated.Id;
    }
}
