using MediatR;

namespace TechBirdsFly.ProjectService.Application.Features.DuplicateProject;

public record DuplicateProjectCommand(
    Guid ProjectId,
    Guid UserId
) : IRequest<Guid>;
