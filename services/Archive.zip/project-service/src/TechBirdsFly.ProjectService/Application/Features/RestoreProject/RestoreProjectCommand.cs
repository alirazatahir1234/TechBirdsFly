using MediatR;

namespace TechBirdsFly.ProjectService.Application.Features.RestoreProject;

/// <summary>
/// Command to restore a project from trash
/// </summary>
public record RestoreProjectCommand(Guid ProjectId, Guid UserId) : IRequest<bool>;
