using MediatR;
using Serilog;
using TechBirdsFly.ProjectService.Domain.Exceptions;
using TechBirdsFly.ProjectService.Domain.Interfaces;

namespace TechBirdsFly.ProjectService.Application.Features.RestoreProject;

/// <summary>
/// Handler to restore a project from trash
/// Performs soft undelete by setting IsDeleted = false
/// </summary>
public class RestoreProjectHandler : IRequestHandler<RestoreProjectCommand, bool>
{
    private readonly IProjectRepository _projects;

    public RestoreProjectHandler(IProjectRepository projects)
    {
        _projects = projects;
    }

    public async Task<bool> Handle(RestoreProjectCommand req, CancellationToken ct)
    {
        Log.Information("Restoring project {ProjectId} from trash", req.ProjectId);

        // Fetch project (include deleted)
        var project = await _projects.GetByIdAsync(req.ProjectId)
            ?? throw new ProjectNotFoundException(req.ProjectId);

        // Verify user owns this project
        if (project.UserId != req.UserId)
        {
            Log.Warning("User {UserId} attempted to restore project {ProjectId} they don't own", req.UserId, req.ProjectId);
            throw new InvalidOperationException("You do not have permission to restore this project");
        }

        // Verify it's in trash
        if (!project.IsDeleted)
        {
            throw new InvalidOperationException("Project is not in trash");
        }

        // Restore from trash
        project.RestoreFromTrash();

        // Save changes
        await _projects.UpdateAsync(project);
        await _projects.SaveChangesAsync();

        Log.Information("Project {ProjectId} restored from trash successfully", req.ProjectId);
        return true;
    }
}
