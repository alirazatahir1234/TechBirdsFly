using MediatR;
using Serilog;
using TechBirdsFly.ProjectService.Domain.Exceptions;
using TechBirdsFly.ProjectService.Domain.Interfaces;

namespace TechBirdsFly.ProjectService.Application.Features.PermanentDelete;

/// <summary>
/// Handler to permanently delete a project from database
/// Hard delete - completely removes project and all versions
/// </summary>
public class PermanentDeleteHandler : IRequestHandler<PermanentDeleteCommand, bool>
{
    private readonly IProjectRepository _projects;

    public PermanentDeleteHandler(IProjectRepository projects)
    {
        _projects = projects;
    }

    public async Task<bool> Handle(PermanentDeleteCommand req, CancellationToken ct)
    {
        Log.Information("Permanently deleting project {ProjectId}", req.ProjectId);

        // Fetch project
        var project = await _projects.GetByIdAsync(req.ProjectId)
            ?? throw new ProjectNotFoundException(req.ProjectId);

        // Verify user owns this project
        if (project.UserId != req.UserId)
        {
            Log.Warning("User {UserId} attempted to permanently delete project {ProjectId} they don't own", req.UserId, req.ProjectId);
            throw new InvalidOperationException("You do not have permission to delete this project");
        }

        // Verify it's in trash (safety check)
        if (!project.IsDeleted)
        {
            Log.Warning("Attempted to permanently delete non-trashed project {ProjectId}", req.ProjectId);
            throw new InvalidOperationException("Only trashed projects can be permanently deleted");
        }

        // Hard delete from database
        await _projects.DeleteAsync(project);
        await _projects.SaveChangesAsync();

        Log.Information("Project {ProjectId} permanently deleted from database", req.ProjectId);
        return true;
    }
}
