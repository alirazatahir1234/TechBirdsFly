using MediatR;

namespace TechBirdsFly.ProjectService.Application.Features.PermanentDelete;

/// <summary>
/// Command to permanently delete a project (hard delete)
/// Only allowed on projects in trash
/// </summary>
public record PermanentDeleteCommand(Guid ProjectId, Guid UserId) : IRequest<bool>;
