using MediatR;

namespace TechBirdsFly.ProjectService.Application.Features.CreateProject;

public record CreateProjectCommand(
    Guid UserId,
    string Name,
    string Industry,
    string Style,
    string Palette,
    string Html
) : IRequest<Guid>;
