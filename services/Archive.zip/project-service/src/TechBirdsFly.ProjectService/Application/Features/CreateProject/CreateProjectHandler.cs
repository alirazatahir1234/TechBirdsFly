using MediatR;
using TechBirdsFly.ProjectService.Domain.Entities;
using TechBirdsFly.ProjectService.Domain.Interfaces;
using TechBirdsFly.ProjectService.Application.Features.GenerateThumbnail;

namespace TechBirdsFly.ProjectService.Application.Features.CreateProject;

public class CreateProjectHandler : IRequestHandler<CreateProjectCommand, Guid>
{
    private readonly IProjectRepository _projects;
    private readonly IVersionRepository _versions;
    private readonly IMediator _mediator;
    private readonly ILogger<CreateProjectHandler> _logger;

    public CreateProjectHandler(
        IProjectRepository projects,
        IVersionRepository versions,
        IMediator mediator,
        ILogger<CreateProjectHandler> logger)
    {
        _projects = projects;
        _versions = versions;
        _mediator = mediator;
        _logger = logger;
    }

    public async Task<Guid> Handle(CreateProjectCommand req, CancellationToken ct)
    {
        var project = new Project(req.UserId, req.Name, req.Industry, req.Style, req.Palette);
        await _projects.AddAsync(project);
        await _projects.SaveChangesAsync();

        var version = new ProjectVersion(project.Id, 1, req.Html);
        await _versions.AddAsync(version);
        await _versions.SaveChangesAsync();

        // Generate thumbnail asynchronously (fire and forget with logging)
        _ = Task.Run(async () =>
        {
            try
            {
                await _mediator.Send(new GenerateThumbnailCommand(project.Id, req.Html), ct);
                _logger.LogInformation("Thumbnail generation completed for project {ProjectId}", project.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to generate thumbnail for project {ProjectId}", project.Id);
            }
        }, ct);

        return project.Id;
    }
}
