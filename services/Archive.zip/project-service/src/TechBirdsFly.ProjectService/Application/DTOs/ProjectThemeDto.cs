namespace TechBirdsFly.ProjectService.Application.DTOs;

public record ProjectThemeDto(
    string? PrimaryColor,
    string? SecondaryColor,
    string? AccentColor,
    string? BackgroundColor,
    string? TextColor,
    string? FontFamily,
    string? FontSizeBase,
    string? BorderRadius
);
