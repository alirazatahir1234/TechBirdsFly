namespace TechBirdsFly.ProjectService.Application.DTOs;

public record ProjectSeoDto(
    string? SeoTitle,
    string? SeoDescription,
    string? SeoKeywords,
    string? OgTitle,
    string? OgDescription,
    string? OgImageUrl
);
