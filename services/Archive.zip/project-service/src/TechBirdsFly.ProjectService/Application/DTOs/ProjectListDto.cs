namespace TechBirdsFly.ProjectService.Application.DTOs;

public record ProjectListDto(
    Guid Id,
    string Name,
    string Industry,
    string Style,
    string Palette,
    DateTime CreatedAt,
    string? ThumbnailUrl
);
