namespace TechBirdsFly.ProjectService.Application.DTOs;

public record ProjectDto(
    Guid Id,
    string Name,
    string Industry,
    string Style,
    string Palette,
    string Html,
    int Version
);
