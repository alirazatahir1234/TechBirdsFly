using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using TechBirdsFly.ProjectService.Domain.Interfaces;
using TechBirdsFly.ProjectService.Infrastructure.Persistence;
using TechBirdsFly.ProjectService.Infrastructure.Repositories;

namespace TechBirdsFly.ProjectService.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructureServices(
        this IServiceCollection services,
        string? connectionString)
    {
        services.AddDbContext<ProjectDbContext>(options =>
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new InvalidOperationException("Connection string 'DefaultConnection' is not configured.");

            options.UseNpgsql(connectionString,
                b => b.MigrationsAssembly("TechBirdsFly.ProjectService"));
        });

        services.AddScoped<IProjectRepository, ProjectRepository>();
        services.AddScoped<IVersionRepository, VersionRepository>();

        return services;
    }
}
