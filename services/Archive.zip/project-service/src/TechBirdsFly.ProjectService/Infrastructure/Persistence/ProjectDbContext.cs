using Microsoft.EntityFrameworkCore;
using TechBirdsFly.ProjectService.Domain.Entities;

namespace TechBirdsFly.ProjectService.Infrastructure.Persistence;

public class ProjectDbContext : DbContext
{
    public ProjectDbContext(DbContextOptions<ProjectDbContext> options) : base(options)
    {
    }

    public DbSet<Project> Projects { get; set; }
    public DbSet<ProjectVersion> ProjectVersions { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Project configuration
        modelBuilder.Entity<Project>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).IsRequired().HasMaxLength(255);
            entity.Property(x => x.Industry).IsRequired().HasMaxLength(100);
            entity.Property(x => x.Style).IsRequired().HasMaxLength(100);
            entity.Property(x => x.Palette).IsRequired().HasMaxLength(100);
            entity.Property(x => x.ThumbnailUrl).HasMaxLength(2000);
            
            // SEO and OG Meta Tags configuration
            entity.Property(x => x.SeoTitle).HasMaxLength(70);
            entity.Property(x => x.SeoDescription).HasMaxLength(160);
            entity.Property(x => x.SeoKeywords).HasMaxLength(200);
            entity.Property(x => x.OgTitle).HasMaxLength(100);
            entity.Property(x => x.OgDescription).HasMaxLength(200);
            entity.Property(x => x.OgImageUrl).HasMaxLength(2000);
            
            // Theme configuration (Colors & Fonts)
            entity.Property(x => x.PrimaryColor).HasMaxLength(7);
            entity.Property(x => x.SecondaryColor).HasMaxLength(7);
            entity.Property(x => x.AccentColor).HasMaxLength(7);
            entity.Property(x => x.BackgroundColor).HasMaxLength(7);
            entity.Property(x => x.TextColor).HasMaxLength(7);
            entity.Property(x => x.FontFamily).HasMaxLength(50);
            entity.Property(x => x.FontSizeBase).HasMaxLength(3);
            entity.Property(x => x.BorderRadius).HasMaxLength(3);
            
            entity.Property(x => x.UserId).IsRequired();
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.UpdatedAt);
            entity.Property(x => x.IsDeleted).IsRequired().HasDefaultValue(false);
            entity.Property(x => x.DeletedAt);

            entity.HasMany(x => x.Versions)
                .WithOne()
                .HasForeignKey(v => v.ProjectId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(x => x.UserId).HasDatabaseName("IX_Projects_UserId");
            entity.HasIndex(x => x.CreatedAt).HasDatabaseName("IX_Projects_CreatedAt");
            entity.HasIndex(x => x.IsDeleted).HasDatabaseName("IX_Projects_IsDeleted");
        });

        // ProjectVersion configuration
        modelBuilder.Entity<ProjectVersion>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.Property(x => x.ProjectId).IsRequired();
            entity.Property(x => x.VersionNumber).IsRequired();
            entity.Property(x => x.Html).IsRequired();
            entity.Property(x => x.CreatedAt).IsRequired();

            entity.HasIndex(x => x.ProjectId).HasDatabaseName("IX_ProjectVersions_ProjectId");
            entity.HasIndex(x => new { x.ProjectId, x.VersionNumber })
                .HasDatabaseName("IX_ProjectVersions_ProjectId_VersionNumber");
        });
    }
}
