using Microsoft.EntityFrameworkCore;
using TechBirdsFly.ProjectService.Domain.Entities;
using TechBirdsFly.ProjectService.Domain.Interfaces;
using TechBirdsFly.ProjectService.Infrastructure.Persistence;

namespace TechBirdsFly.ProjectService.Infrastructure.Repositories;

public class VersionRepository : IVersionRepository
{
    private readonly ProjectDbContext _context;

    public VersionRepository(ProjectDbContext context)
    {
        _context = context;
    }

    public async Task<int> GetLastVersionAsync(Guid projectId)
    {
        var lastVersion = await _context.ProjectVersions
            .Where(v => v.ProjectId == projectId)
            .OrderByDescending(v => v.VersionNumber)
            .FirstOrDefaultAsync();

        return lastVersion?.VersionNumber ?? 0;
    }

    public async Task AddAsync(ProjectVersion version)
    {
        await _context.ProjectVersions.AddAsync(version);
    }

    public async Task<List<ProjectVersion>> GetByProjectIdAsync(Guid projectId)
    {
        return await _context.ProjectVersions
            .Where(v => v.ProjectId == projectId)
            .OrderByDescending(v => v.VersionNumber)
            .ToListAsync();
    }

    public async Task SaveChangesAsync()
    {
        await _context.SaveChangesAsync();
    }
}
