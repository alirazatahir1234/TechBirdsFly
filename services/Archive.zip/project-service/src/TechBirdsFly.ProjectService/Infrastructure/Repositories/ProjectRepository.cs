using Microsoft.EntityFrameworkCore;
using TechBirdsFly.ProjectService.Domain.Entities;
using TechBirdsFly.ProjectService.Domain.Interfaces;
using TechBirdsFly.ProjectService.Infrastructure.Persistence;

namespace TechBirdsFly.ProjectService.Infrastructure.Repositories;

public class ProjectRepository : IProjectRepository
{
    private readonly ProjectDbContext _context;

    public ProjectRepository(ProjectDbContext context)
    {
        _context = context;
    }

    public async Task<Project?> GetByIdAsync(Guid id)
    {
        return await _context.Projects
            .Include(p => p.Versions)
            .FirstOrDefaultAsync(p => p.Id == id);
    }

    public async Task<List<Project>> GetByUserIdAsync(Guid userId)
    {
        return await _context.Projects
            .Where(p => p.UserId == userId && !p.IsDeleted)
            .Include(p => p.Versions)
            .ToListAsync();
    }

    public async Task<List<Project>> GetAllAsync()
    {
        return await _context.Projects
            .Include(p => p.Versions)
            .ToListAsync();
    }

    public async Task AddAsync(Project project)
    {
        await _context.Projects.AddAsync(project);
    }

    public async Task UpdateAsync(Project project)
    {
        _context.Projects.Update(project);
        await Task.CompletedTask;
    }

    public async Task DeleteAsync(Project project)
    {
        _context.Projects.Remove(project);
        await Task.CompletedTask;
    }

    public async Task SaveChangesAsync()
    {
        await _context.SaveChangesAsync();
    }
}
